import { useState, useMemo } from 'react'
import { Form, Input, message, Typography } from 'antd'
import { LockOutlined, MailOutlined, EyeOutlined, EyeInvisibleOutlined } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../stores/authStore'

const { Text } = Typography

export default function LoginPage() {
  const [loading, setLoading] = useState(false)
  const [isRegister, setIsRegister] = useState(false)
  const navigate = useNavigate()
  const { login, register } = useAuthStore()

  const onFinish = async (values: { email: string; password: string }) => {
    setLoading(true)
    try {
      let success: boolean
      if (isRegister) {
        success = await register(values.email, values.password)
        if (success) {
          message.success('注册成功！')
        } else {
          message.error('该邮箱已被注册')
          setLoading(false)
          return
        }
      } else {
        success = await login(values.email, values.password)
        if (!success) {
          message.error('邮箱或密码错误')
          setLoading(false)
          return
        }
      }
      navigate('/')
    } catch (error) {
      message.error('操作失败，请重试')
    }
    setLoading(false)
  }

  // Generate deterministic particles
  const particles = useMemo(() =>
    [...Array(30)].map((_, i) => ({
      id: i,
      left: ((i * 37 + 13) % 100),
      top: ((i * 53 + 7) % 100),
      delay: ((i * 2.3) % 10),
      duration: 5 + (i % 7),
      size: 3 + (i % 5),
      opacity: 0.2 + (i % 5) * 0.08,
      type: i % 3 // 0: dot, 1: ring, 2: cross
    })), [])

  // Generate orbital rings
  const orbits = useMemo(() =>
    [...Array(5)].map((_, i) => ({
      id: i,
      size: 200 + i * 120,
      duration: 20 + i * 8,
      delay: i * -4,
      opacity: 0.03 + i * 0.01
    })), [])

  // Generate floating lines
  const lines = useMemo(() =>
    [...Array(8)].map((_, i) => ({
      id: i,
      x1: ((i * 41 + 17) % 80) + 10,
      y1: ((i * 29 + 11) % 80) + 10,
      angle: (i * 45) % 360,
      length: 60 + (i % 4) * 30,
      duration: 12 + (i % 5) * 3,
      delay: i * -2,
      opacity: 0.04 + (i % 3) * 0.02
    })), [])

  return (
    <div className="login-page">
      {/* Dynamic background */}
      <div className="login-bg">
        {/* Base gradient */}
        <div className="login-bg-gradient" />

        {/* Animated mesh grid */}
        <div className="login-bg-mesh" />

        {/* Orbital rings */}
        <div className="login-bg-orbits">
          {orbits.map(o => (
            <div key={o.id} className="login-orbit" style={{
              width: o.size,
              height: o.size,
              animationDuration: `${o.duration}s`,
              animationDelay: `${o.delay}s`,
              opacity: o.opacity
            }} />
          ))}
        </div>

        {/* Floating connection lines */}
        <div className="login-bg-lines">
          {lines.map(l => (
            <div key={l.id} className="login-line" style={{
              left: `${l.x1}%`,
              top: `${l.y1}%`,
              transform: `rotate(${l.angle}deg)`,
              width: l.length,
              animationDuration: `${l.duration}s`,
              animationDelay: `${l.delay}s`,
              opacity: l.opacity
            }} />
          ))}
        </div>

        {/* Multi-layer glow orbs */}
        <div className="login-bg-glow login-bg-glow-1" />
        <div className="login-bg-glow login-bg-glow-2" />
        <div className="login-bg-glow login-bg-glow-3" />
        <div className="login-bg-glow login-bg-glow-4" />

        {/* Particles */}
        <div className="login-bg-particles">
          {particles.map(p => (
            <div key={p.id} className={`login-particle login-particle-${p.type}`} style={{
              left: `${p.left}%`,
              top: `${p.top}%`,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
              width: p.size,
              height: p.size,
              opacity: p.opacity
            }} />
          ))}
        </div>

        {/* Data flow lines (horizontal scanning) */}
        <div className="login-bg-scanlines">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="login-scanline" style={{
              animationDelay: `${i * 4}s`,
              animationDuration: `${8 + i * 2}s`,
              top: `${25 + i * 25}%`
            }} />
          ))}
        </div>
      </div>

      {/* Login card */}
      <div className="login-container">
        <div className="login-card">
          {/* Brand */}
          <div className="login-brand">
            <div className="login-logo">
              <svg viewBox="0 0 40 40" fill="none" width="48" height="48">
                <rect x="2" y="2" width="36" height="36" rx="10" fill="url(#logoGrad)" />
                <path d="M20 10v20M12 20h16" stroke="#0a0e1a" strokeWidth="2.5" strokeLinecap="round" />
                <circle cx="20" cy="20" r="8" stroke="#0a0e1a" strokeWidth="1.5" fill="none" opacity="0.4" />
                <defs>
                  <linearGradient id="logoGrad" x1="2" y1="2" x2="38" y2="38">
                    <stop stopColor="#d8be88" />
                    <stop offset="1" stopColor="#b08d4f" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <h1 className="login-title">Wealth Terminal</h1>
            <p className="login-subtitle">财富管理智能体</p>
          </div>

          {/* Form */}
          <Form
            name="auth"
            onFinish={onFinish}
            autoComplete="off"
            layout="vertical"
            requiredMark={false}
          >
            <div className="login-form-label">邮箱地址</div>
            <Form.Item
              name="email"
              rules={[
                { required: true, message: '请输入邮箱' },
                { type: 'email', message: '请输入有效的邮箱地址' }
              ]}
              style={{ marginBottom: 20 }}
            >
              <Input
                prefix={<MailOutlined style={{ color: 'rgba(201,167,106,0.6)' }} />}
                placeholder="your@email.com"
                className="login-input"
                size="large"
              />
            </Form.Item>

            <div className="login-form-label">密码</div>
            <Form.Item
              name="password"
              rules={[
                { required: true, message: '请输入密码' },
                { min: 6, message: '密码至少6位' }
              ]}
              style={{ marginBottom: 28 }}
            >
              <Input.Password
                prefix={<LockOutlined style={{ color: 'rgba(201,167,106,0.6)' }} />}
                placeholder="输入密码"
                className="login-input"
                size="large"
                iconRender={(visible) => visible
                  ? <EyeOutlined style={{ color: 'rgba(100,100,120,0.5)' }} />
                  : <EyeInvisibleOutlined style={{ color: 'rgba(100,100,120,0.5)' }} />
                }
              />
            </Form.Item>

            <Form.Item style={{ marginBottom: 20 }}>
              <button
                type="submit"
                className={`login-submit-btn ${loading ? 'loading' : ''}`}
                disabled={loading}
              >
                {loading ? (
                  <span className="login-btn-loading">
                    <span className="login-spinner" />
                    处理中…
                  </span>
                ) : (
                  isRegister ? '创建账号' : '登录'
                )}
              </button>
            </Form.Item>
          </Form>

          {/* Switch */}
          <div className="login-switch">
            <Text style={{ color: 'rgba(80,80,100,0.6)', fontSize: 13 }}>
              {isRegister ? '已有账号？' : '还没有账号？'}
            </Text>
            <a
              className="login-switch-link"
              onClick={() => setIsRegister(!isRegister)}
            >
              {isRegister ? '立即登录' : '立即注册'}
            </a>
          </div>

          {/* Footer */}
          <div className="login-footer">
            <span className="login-footer-dot" />
            <span>端到端加密 · 数据安全</span>
            <span className="login-footer-dot" />
          </div>
        </div>
      </div>
    </div>
  )
}
