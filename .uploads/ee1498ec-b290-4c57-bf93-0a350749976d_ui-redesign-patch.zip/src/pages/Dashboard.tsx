// 财富管理智能体 — 主页面（深色顶栏 + Pill Tab）
// 设计风格：Modern Wealth Terminal
// 数据流：
//   - 资产总览：assetStore + holdingStore（持仓联动合并）
//   - 资产管理：assetStore + holdingStore（持仓联动合并）
//   - 持仓管理：holdingStore（唯一写入端）
//   - AI投顾：读取 assetStore + holdingStore 做上下文

import { useState, useEffect, useRef } from 'react'
import { message, Tooltip } from 'antd'
import {
  ReloadOutlined,
  LogoutOutlined,
  BellOutlined,
  ThunderboltOutlined
} from '@ant-design/icons'
import { useAuthStore } from '../renderer/stores/authStore'
import { useHoldingStore } from '../stores/holdingStore'
import { useAssetStore } from '../stores/assetStore'
import { useNavigate } from 'react-router-dom'
import PortfolioOverview from '../components/PortfolioOverview'
import AssetList from '../components/AssetList'
import HoldingList from '../components/HoldingList'
import AIAdvisor from '../components/AIAdvisor'
import { fetchIndexQuotes, type IndexQuote } from '../services/stockService'

/* Modern Tab Icons — Refined Line Art */
const TabIconOverview = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" width="1em" height="1em">
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="4" />
    <line x1="12" y1="2" x2="12" y2="5" />
    <line x1="12" y1="19" x2="12" y2="22" />
    <line x1="2" y1="12" x2="5" y2="12" />
    <line x1="19" y1="12" x2="22" y2="12" />
  </svg>
)

const TabIconAssets = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" width="1em" height="1em">
    <rect x="3" y="6" width="18" height="14" rx="2.5" />
    <line x1="3" y1="10" x2="21" y2="10" />
    <line x1="8" y1="6" x2="8" y2="3" />
    <line x1="16" y1="6" x2="16" y2="3" />
    <line x1="6" y1="3" x2="18" y2="3" />
    <circle cx="12" cy="14" r="2" />
  </svg>
)

const TabIconHoldings = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 28 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" width="1em" height="1em">
    {/* 4 ascending coin stacks — staircase growth */}
    {/* Stack 1: 2 coins */}
    <ellipse cx="5" cy="20" rx="3" ry="1.2" />
    <path d="M2 20v-2.5" />
    <path d="M8 20v-2.5" />
    <ellipse cx="5" cy="17.5" rx="3" ry="1.2" />
    {/* Stack 2: 3 coins */}
    <ellipse cx="10.5" cy="20" rx="3" ry="1.2" />
    <path d="M7.5 20v-4" />
    <path d="M13.5 20v-4" />
    <ellipse cx="10.5" cy="16" rx="3" ry="1.2" />
    <path d="M7.5 16v-2" />
    <path d="M13.5 16v-2" />
    <ellipse cx="10.5" cy="14" rx="3" ry="1.2" />
    {/* Stack 3: 4 coins */}
    <ellipse cx="16" cy="20" rx="3" ry="1.2" />
    <path d="M13 20v-5.5" />
    <path d="M19 20v-5.5" />
    <ellipse cx="16" cy="14.5" rx="3" ry="1.2" />
    <path d="M13 14.5v-2.5" />
    <path d="M19 14.5v-2.5" />
    <ellipse cx="16" cy="12" rx="3" ry="1.2" />
    <path d="M13 12v-2" />
    <path d="M19 12v-2" />
    <ellipse cx="16" cy="10" rx="3" ry="1.2" />
    {/* Stack 4: 5 coins */}
    <ellipse cx="21.5" cy="20" rx="3" ry="1.2" />
    <path d="M18.5 20v-7" />
    <path d="M24.5 20v-7" />
    <ellipse cx="21.5" cy="13" rx="3" ry="1.2" />
    <path d="M18.5 13v-3" />
    <path d="M24.5 13v-3" />
    <ellipse cx="21.5" cy="10" rx="3" ry="1.2" />
    <path d="M18.5 10v-2.5" />
    <path d="M24.5 10v-2.5" />
    <ellipse cx="21.5" cy="7.5" rx="3" ry="1.2" />
    <path d="M18.5 7.5v-2" />
    <path d="M24.5 7.5v-2" />
    <ellipse cx="21.5" cy="5.5" rx="3" ry="1.2" />
  </svg>
)

const TabIconAI = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" width="1em" height="1em">
    <path d="M12 2L9 9H3l5 4-2 7 6-4.5L18 20l-2-7 5-4h-6L12 2z" />
  </svg>
)

const TABS = [
  { key: 'overview',   label: '资产总览', icon: <TabIconOverview /> },
  { key: 'management', label: '资产管理', icon: <TabIconAssets /> },
  { key: 'holdings',   label: '持仓管理', icon: <TabIconHoldings /> },
  { key: 'advisor',    label: 'AI 投顾',  icon: <TabIconAI /> }
]

export default function Dashboard() {
  const { user, logout } = useAuthStore()
  const { refreshPrices, refreshing, holdings } = useHoldingStore()
  const { loadAssets } = useAssetStore()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('overview')
  const [indexQuotes, setIndexQuotes] = useState<IndexQuote[]>([])
  const [indexLoading, setIndexLoading] = useState(true)
  const autoRefreshTimer = useRef<ReturnType<typeof setInterval> | null>(null)
  const indexTimer = useRef<ReturnType<typeof setInterval> | null>(null)

  const loadIndexQuotes = async () => {
    try {
      const quotes = await fetchIndexQuotes()
      if (quotes.length > 0) setIndexQuotes(quotes)
    } catch (e) {
      console.warn('[index] 大盘指数拉取失败:', e)
    } finally {
      setIndexLoading(false)
    }
  }

  useEffect(() => {
    refreshPrices()
    loadIndexQuotes()
    autoRefreshTimer.current = setInterval(() => {
      refreshPrices()
    }, 300_000) // 5分钟
    indexTimer.current = setInterval(() => {
      loadIndexQuotes()
    }, 60_000) // 大盘指数 1 分钟刷新一次

    const handler = (e: any) => {
      if (e.detail?.key) setActiveTab(e.detail.key)
    }
    window.addEventListener('switch-tab', handler)

    return () => {
      if (autoRefreshTimer.current) {
        clearInterval(autoRefreshTimer.current)
        autoRefreshTimer.current = null
      }
      if (indexTimer.current) {
        clearInterval(indexTimer.current)
        indexTimer.current = null
      }
      window.removeEventListener('switch-tab', handler)
    }
  }, [])

  const handleLogout = () => {
    if (autoRefreshTimer.current) {
      clearInterval(autoRefreshTimer.current)
      autoRefreshTimer.current = null
    }
    if (indexTimer.current) {
      clearInterval(indexTimer.current)
      indexTimer.current = null
    }
    logout()
    message.success('已退出登录')
    navigate('/login')
  }

  const handleRefresh = async () => {
    message.info('正在刷新数据…')
    await Promise.all([refreshPrices(), loadAssets(), loadIndexQuotes()])
    message.success('刷新完成')
  }

  const handleTabChange = (key: string) => {
    setActiveTab(key)
    if (key === 'holdings') refreshPrices()
    if (key === 'overview' || key === 'management') {
      loadAssets()
      refreshPrices()
    }
  }

  const userInitial = (user?.email || 'U').charAt(0).toUpperCase()
  const portfolioCount = holdings.length

  // 用真实指数数据，没有就用占位
  const shIndex = indexQuotes.find(q => q.code === 'sh000001')

  return (
    <div className="app-shell">
      {/* ===== Top Bar ===== */}
      <header className="app-topbar">
        <div className="brand-block">
          <div className="brand-mark">¥</div>
          <div className="brand-text">
            <span className="brand-title">Wealth Terminal</span>
            <span className="brand-sub">财富管理智能体</span>
          </div>
        </div>

        {/* Market Ticker */}
        <div className="market-ticker">
          <span className="ticker-slogan">禁加杠杆，复利变富</span>
          <div className="ticker-pill" title={shIndex?.updateTime ? `更新于 ${shIndex.updateTime}` : ''}>
            <span className="label">上证</span>
            {shIndex ? (
              <>
                <span className="val">{shIndex.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span className={`change ${shIndex.changePercent >= 0 ? 'up' : 'down'}`}>
                  {shIndex.changePercent >= 0 ? '+' : ''}{shIndex.change.toFixed(2)}
                  <span className="pct">
                    {shIndex.changePercent >= 0 ? '▲' : '▼'} {Math.abs(shIndex.changePercent).toFixed(2)}%
                  </span>
                </span>
              </>
            ) : (
              <span className="val muted">——</span>
            )}
          </div>
          {(refreshing || indexLoading) && (
            <div className="ticker-pill">
              <span className="live-dot busy" />
              <span className="label">{refreshing ? '同步中' : '加载指数…'}</span>
            </div>
          )}
        </div>

        <div className="user-block">
          <Tooltip title="实时刷新">
            <button
              onClick={handleRefresh}
              style={{
                background: 'transparent',
                border: 'none',
                color: 'rgba(255,255,255,0.7)',
                cursor: 'pointer',
                padding: 6,
                display: 'flex'
              }}
            >
              <ReloadOutlined spin={refreshing} style={{ fontSize: 14 }} />
            </button>
          </Tooltip>
          <span className="user-email">{user?.email}</span>
          <div className="user-avatar">{userInitial}</div>
          <Tooltip title="退出登录">
            <button
              onClick={handleLogout}
              style={{
                background: 'transparent',
                border: 'none',
                color: 'rgba(255,255,255,0.7)',
                cursor: 'pointer',
                padding: 6,
                display: 'flex',
                marginLeft: 2
              }}
            >
              <LogoutOutlined style={{ fontSize: 14 }} />
            </button>
          </Tooltip>
        </div>
      </header>

      {/* ===== Main Container ===== */}
      <main style={{
        flex: 1,
        maxWidth: 1440,
        width: '100%',
        margin: '0 auto',
        padding: '28px 32px 40px'
      }}>
        {/* Tab Bar */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <div className="tab-bar fade-in">
            {TABS.map((t, idx) => (
              <div
                key={t.key}
                className={`tab-item ${activeTab === t.key ? 'active' : ''}`}
                onClick={() => handleTabChange(t.key)}
              >
                {t.icon}
                <span>{t.label}</span>
                <span className="tab-num">0{idx + 1}</span>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }} className="fade-in-1">
            <span className="chip muted">
              <span className="dot" />
              数据本地优先 · 云端同步
            </span>
            <span className="chip ink">
              <ThunderboltOutlined style={{ fontSize: 11 }} />
              AI 增强
            </span>
          </div>
        </div>

        {/* Tab Content */}
        <div className="tab-content-wrapper" key={activeTab}>
          {activeTab === 'overview'   && <PortfolioOverview />}
          {activeTab === 'management' && <AssetList />}
          {activeTab === 'holdings'   && <HoldingList />}
          {activeTab === 'advisor'    && <AIAdvisor />}
        </div>
      </main>

      {/* ===== Mobile Bottom Tab Bar ===== */}
      <nav className="mobile-tab-bar">
        {TABS.map(t => {
          const isActive = activeTab === t.key
          return (
            <div
              key={t.key}
              className={`mobile-tab-item ${isActive ? 'active' : ''}`}
              onClick={() => handleTabChange(t.key)}
            >
              <span className="mobile-tab-icon">{t.icon}</span>
              <span className="mobile-tab-label">{t.label}</span>
            </div>
          )
        })}
      </nav>
    </div>
  )
}
